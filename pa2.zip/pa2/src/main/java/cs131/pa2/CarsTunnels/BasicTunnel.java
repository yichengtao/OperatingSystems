package cs131.pa2.CarsTunnels;

import java.util.LinkedList;
import java.util.List;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;

/**
 * 
 * The class for the Basic Tunnel, extending Tunnel.
 * @author cs131a
 *
 */
public class BasicTunnel extends Tunnel {

	/**
	 * The maximal number of cars a tunnel can contain
	 */
	private static final int SIZE_CARS = 3;
	/**
	 * The maximal number of sleds a tunnel can contain
	 */
	private static final int SIZE_SLEDS = 1;
	/**
	 * The counter to count the number of cars and sleds in the tunnel
	 */
	private int[] count;
	/**
	 * The list of vehicles in the tunnel
	 */
	private List<Vehicle> vehicles;
	/**
	 * The ambulance in the tunnel (a special vehicle not included in vehicles)
	 */
	private Ambulance ambulance;

	/**
	 * Creates a new instance of a basic tunnel with the given name
	 * @param name The name of the basic tunnel
	 */
	public BasicTunnel(String name) {
		super(name);
		count = new int[2];
		vehicles = new LinkedList<Vehicle>();
	}

	@Override
	protected synchronized boolean tryToEnterInner(Vehicle vehicle) {
		if (vehicle == null) {
			return false;
		}
		int sizeOfType;
		int countIdx;
		// check the type of vehicle
		if (vehicle instanceof Car) {
			sizeOfType = SIZE_CARS;
			countIdx = 0;
		} else if (vehicle instanceof Sled) {
			sizeOfType = SIZE_SLEDS;
			countIdx = 1;
		} else if (vehicle instanceof Ambulance) {
			if (ambulance != null) {
				return false;
			}
			ambulance = (Ambulance) vehicle;
			return true;
		} else {
			return false;
		}
		// fail to enter if the tunnel is filled with other type of vehicles or full
		if (count[1-countIdx] > 0 || count[countIdx] == sizeOfType) {
			return false;
		}
		// fail to enter if vehicle has a different direction from the vehicles in the tunnel
		if (count[countIdx] > 0 && vehicles.get(0).getDirection() != vehicle.getDirection()) {
			return false;
		}
		// add vehicle to vehicles
		count[countIdx]++;
		vehicles.add(vehicle);
		return true;
	}

	@Override
	public synchronized void exitTunnelInner(Vehicle vehicle) {
		if (vehicle instanceof Ambulance) {
			if (vehicle.equals(ambulance)) {
				ambulance = null;
			}
		} else if (vehicles.contains(vehicle)) {
			vehicles.remove(vehicle); // remove vehicle from vehicles
			if (count[0] > 0) {
				count[0]--;
			} else {
				count[1]--;
			}
		}
	}
	
	/**
	 * Gets the ambulance in the tunnel
	 * @return the ambulance in the tunnel, none if not exists
	 */
	public synchronized Ambulance getAmbulance() {
		return ambulance;
	}
	
}
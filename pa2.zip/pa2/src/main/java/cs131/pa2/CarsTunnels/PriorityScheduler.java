package cs131.pa2.CarsTunnels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

/**
 * The priority scheduler assigns vehicles to tunnels based on their priority
 * It extends the Tunnel class.
 * @author cs131a
 *
 */
public class PriorityScheduler extends Tunnel {

	/**
	 * The lock used for the condition variables
	 */
	private final Lock lock = new ReentrantLock();
	/**
	 * The highest priority value
	 */
	private final static int HIGHEST_PRIORITY = 4;
	/**
	 * The condition variables for vehicles of each priority value
	 */
	private Condition[] conditions;
	/**
	 * The counters to count the number of vehicles in each condition variable
	 */
	private int[] counters;
	/**
	 * The collection of basic tunnels that the priority scheduler should manage
	 */
	private Collection<BasicTunnel> tunnels;
	/**
	 * The map to map the vehicle to the basic tunnel it is in
	 */
	private Map<Vehicle, BasicTunnel> vehicleMap;
	
	/**
	 * Creates a new instance of the class PriorityScheduler with the given name, collection of tunnels, and log
	 * @param name The name of the priority scheduler to create
	 * @param tunnels The tunnels that the priority scheduler should manage
	 * @param log The log for logging the operations
	 */
	public PriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		conditions = new Condition[HIGHEST_PRIORITY + 1];
		for (int i = 0; i <= HIGHEST_PRIORITY; i++) {
			conditions[i] = lock.newCondition();
		}
		counters = new int[HIGHEST_PRIORITY + 1];
		this.tunnels = new ArrayList<BasicTunnel>();
		for (Tunnel tunnel : tunnels) {
			this.tunnels.add((BasicTunnel) tunnel); 
		}
		vehicleMap = new HashMap<Vehicle, BasicTunnel>();
	}

	/**
	 * Vehicle tries to enter a tunnel; if it can not, it waits in a condition corresponding to its priority
	 * @param vehicle The vehicle that is attempting to enter
	 * @return true if the vehicle was able to enter, false otherwise
	 */
	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
		lock.lock();
		try {
			if (vehicle == null) {
				return false;
			}
			while (vehicle.getPriority() < getCurrHighestPriority() || !tryToEnterInnerBasicTunnels(vehicle)) {
				counters[vehicle.getPriority()]++; // update the corresponding counter
				conditions[vehicle.getPriority()].await(); // wait in the corresponding condition
				counters[vehicle.getPriority()]--;
			}
			return true;
		} catch (InterruptedException e) {
			return false;
		} finally {
			lock.unlock();
		}
	}

	/**
	 * Vehicle exits the tunnel and signals a waiting vehicle with the highest priority to enter
	 * @param vehicle The vehicle that is exiting the tunnel
	 */
	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		try {
			if (vehicle != null && vehicleMap.containsKey(vehicle)) {
				vehicleMap.get(vehicle).exitTunnel(vehicle); // remove vehicle from the tunnel it's in
				vehicleMap.remove(vehicle);
				int currHighestPriority = getCurrHighestPriority();
				if (currHighestPriority >= 0) {
					conditions[currHighestPriority].signal(); // signal the vehicle with the highest priority
				}
			}
		} finally {
			lock.unlock();
		}
	}

	/**
	 * Vehicle tries to enter a tunnel from the collection of basic tunnels of this priority scheduler 
	 * @param vehicle The vehicle that is attempting to enter
	 * @return true if the vehicle was able to enter, false otherwise
	 */
	private boolean tryToEnterInnerBasicTunnels(Vehicle vehicle) {
		for (BasicTunnel tunnel : tunnels) {
			if (tunnel.tryToEnter(vehicle)) {
				vehicleMap.put(vehicle, tunnel);
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the current highest priority value of waiting vehicles
	 * @return the current highest priority value of waiting vehicles, -1 if none
	 */
	private int getCurrHighestPriority() {
		for (int i = HIGHEST_PRIORITY; i >= 0; i--) {
			if (counters[i] != 0) {
				return i;
			}
		}
		return -1;
	}

}
// Yicheng Tao
// yichengtao@brandeis.edu

/**
 * Your code goes in this file
 * fill in the empty methods to allow for the required
 * operations. You can add any fields or methods you want
 * to help in your implementations.
 * 
 */

public class AVLPlayerNode{
	private Player data;
	private double value;
	private AVLPlayerNode parent;
	private AVLPlayerNode leftChild;
	private AVLPlayerNode rightChild;
	private int rightWeight;
	private int balanceFactor;
	private int height;

	/**
	 * Constructor to create a AVLPlayerNode
	 * @param data the player object
	 * @param value that the node is sorted based on
	 */
	public AVLPlayerNode(Player data,double value){
		this.data = data;
		this.value = value;
	}

	/**
	 * Insert a node with the given player and its value
	 * Make sure to update the balance factor and right weight
	 * and use rotations to maintain AVL condition
	 * @param newGuy the player to insert
	 * @param value of the player that is sorting-based-on
	 * @return the new root of the tree
	 */
	public AVLPlayerNode insert(Player newGuy,double value){
		AVLPlayerNode v = null;
		AVLPlayerNode w = this;
		AVLPlayerNode z = new AVLPlayerNode(newGuy, value);
		// find the right place to insert
		while (w != null) {
			v = w;
			if (z.value <= w.value) {
				w = w.leftChild;
			} else {
				w = w.rightChild;
			}
		}
		// make the connection between the new node and its parent
		z.parent = v;
		if (v != null) {
			if (z.value <= v.value) {
				v.leftChild = z;
			} else {
				v.rightChild = z;
			}
		}
		// update the right weight, balance factor, and height
		z.setRightWeightForAncestors(1);
		z.setBFAndHeightForSelfAndAnc();
		// rotate to re-balance the tree
		v.rotateAfterInsertion();
		return findRoot();
	}


	/**
	 * Delete a node according to the given value
	 * Remember to update the right weight
	 * @param value that is sorting-based-on
	 * @return the new root of the tree
	 */
	public AVLPlayerNode delete(double value) {
		//standard vanilla BST delete method
		AVLPlayerNode z = getNode(value);
		if (z != null) {
			AVLPlayerNode y = null;
			AVLPlayerNode x = null;
			// find the node to delete
			if (z.leftChild == null || z.rightChild == null) {
				y = z;
			} else {
				y = z.BSTSuccessor();
			}
			// delete the node and make new connection between child and parent
			if (y.leftChild != null) {
				x = y.leftChild;
			} else {
				x = y.rightChild;
			}
			if (x != null) {
				x.parent = y.parent;
			}
			if (y.parent != null) {
				y.setRightWeightForAncestors(-1);
				if (y == y.parent.leftChild) {
					y.parent.leftChild = x;
				} else {
					y.parent.rightChild = x;
				}
			}
			// if y = z.BSTSuccessor() then copy y's data into z
			if (y != z) {
				z.data = y.data;
				z.value = y.value;
			}
			//Extra Credit: use rotations to maintain the AVL condition
			y.setBFAndHeightForSelfAndAnc();
			if (y.parent != null) {
				y.parent.rotateAfterDeletion();
			}
		}
		return findRoot();
	}

	/**
	 * Implement right rotation operation 
	 * Remember to maintain rightWeight
	 */
	private void rotateRight() {
		if (leftChild != null) {
			AVLPlayerNode tmp = leftChild;
			// set the new left child for "this" node 
			leftChild = tmp.rightChild;
			if (tmp.rightChild != null) {
				tmp.rightChild.parent = this;
			}
			// set the new parent for this.leftChild node
			tmp.parent = parent;
			if (parent != null) {
				if (this == parent.rightChild) {
					parent.rightChild = tmp; 
				} else {
					parent.leftChild = tmp;
				}
			}
			// set the new connection between this and this.leftChild
			tmp.rightChild = this;
			parent = tmp;
			// update the right weight, balance factor, and height for each node
			tmp.rightWeight += (1 + rightWeight);
			setBFAndHeightForSelfAndAnc();
		}
	}

	/**
	 * Implement right rotation operation 
	 * Remember to maintain rightWeight
	 */
	private void rotateLeft() {
		if (rightChild != null) {
			AVLPlayerNode tmp = rightChild;
			// set the new right child for "this" node 
			rightChild = tmp.leftChild;
			if (tmp.leftChild != null) {
				tmp.leftChild.parent = this;
			}
			// set the new parent for this.rightChild node
			tmp.parent = parent;
			if (parent != null) {
				if (this == parent.leftChild) {
					parent.leftChild = tmp; 
				} else {
					parent.rightChild = tmp;
				}
			}
			// set the new connection between this and this.rightChild
			tmp.leftChild = this;
			parent = tmp;
			// update the right weight, balance factor, and height for each node
			rightWeight -= (1 + tmp.rightWeight);
			setBFAndHeightForSelfAndAnc();
		}
	}

	/**
	 * Perform appropriate rotation after insertion
	 * @param v the head node
	 */
	public void rotateAfterInsertion() {
		AVLPlayerNode curr = this;
		while (curr != null) {
			if (curr.balanceFactor < -1) { // tree right heavy
				if (curr.rightChild.balanceFactor > 0) { // tree left heavy
					curr.rightChild.rotateRight(); // double RL-rotation
					curr.rotateLeft();
				} else {
					curr.rotateLeft(); // single rotation
				}
				break;
			} else if (curr.balanceFactor > 1) { // tree left heavy
				if (curr.leftChild.balanceFactor < 0) { // tree right jeavy
					curr.leftChild.rotateLeft(); // double LR-rotation
					curr.rotateRight();
				} else {
					curr.rotateRight(); // single rotation
				}
				break;
			}
			curr = curr.parent;
		}
	}

	/**
	 * Perform rotation after deletion
	 */
	public void rotateAfterDeletion() {
		AVLPlayerNode curr = this;
		while (curr != null) {
			// if the deleted node is in curr's left subtree
			if (curr.balanceFactor > 1) {
				AVLPlayerNode z = curr.leftChild;
				if (z.balanceFactor == 0 || z.balanceFactor == 1) {
					curr.rotateRight(); // single right rotation
				} else {
					z.rotateLeft(); // left-right rotation
					curr.rotateRight();
				}
				break;
			} else if (curr.balanceFactor < -1) { // if the deleted node is in curr's right subtree
				AVLPlayerNode z = curr.rightChild;
				if (z.balanceFactor == 0 || z.balanceFactor == -1) {
					curr.rotateLeft(); // single left rotation
				} else {
					z.rotateRight(); // right-left rotation
					curr.rotateLeft();
				}
				break;
			}
			curr = curr.parent;
		}
	}

	/**
	 * Get the player with the given value in the subtree of the node, null if not found
	 * @param value that is sorting-based-on
	 * @return the Player object stored in the node with this.value == value
	 */
	public Player getPlayer(double value){
		AVLPlayerNode v = getNode(value); // find the node with the given value
		if (v == null) {
			return null;
		} else {
			return v.data; // return the player object
		}
	}

	/**
	 * Get the tree node of the given value in the subtree of the node
	 * @param value
	 * @return the tree node
	 */
	public AVLPlayerNode getNode(double value) {
		if (value == this.value) {
			return this;
		} else if (value > this.value) { // find the node in the right subtree
			if (rightChild != null) {
				return rightChild.getNode(value);
			}
		} else {
			if (leftChild != null) { // find the node in the left subtree
				return leftChild.getNode(value);
			}
		}
		return null;
	}

	/**
	 * Get the rank of the given value in the subtree of the node, 0 if not found
	 * @param value that is sorting-based-on
	 * @return the rank of the node with this.value == value
	 */
	public int getRank(double value) {
		if (value == this.value) {
			// find the best rank of the duplicate scores
			if (rightChild != null) {
				int r = rightChild.getRank(value); 
				if (r != 0) {
					return r;
				}
			}
			return rightWeight + 1; // no duplicate scores
		} else if (value < this.value) { // find the rank in the left subtree
			if (leftChild != null) {
				int leftRank = leftChild.getRank(value);
				if (leftRank > 0) { // if found
					return leftRank + 1 + rightWeight;
				}
			}
		} else {
			if (rightChild != null) { // find the rank in the right subtree
				return rightChild.getRank(value);
			}
		}
		return 0;
	}

	/**
	 * Set the right weights of the ancestors
	 * @param adt the additive right weight
	 */
	public void setRightWeightForAncestors(int adt) {
		AVLPlayerNode curr = this;
		while (curr.parent != null) {
			if (curr == curr.parent.rightChild) {
				curr.parent.rightWeight += adt; // update the right weight for some ancestors influenced
			}
			curr = curr.parent;
		}
	}


	/**
	 * Get the height of the given node
	 * @param v the given node
	 * @return the height
	 */
	public int getHeight(AVLPlayerNode v) {
		if (v == null) {
			return -1; // height will be -1 if the node is null
		} else {
			return v.height; 
		}
	}


	/**
	 * Set the balance factor and height for ancestors
	 */
	public void setBFAndHeightForSelfAndAnc() {
		AVLPlayerNode curr = this;
		while (curr != null) {
			curr.balanceFactor = getHeight(curr.leftChild) - getHeight(curr.rightChild); // bf = hleft - hright
			curr.height = 1 + Math.max(getHeight(curr.leftChild), getHeight(curr.rightChild)); // h = 1 + max(hleft, hright)
			curr = curr.parent;
		}
	}


	/**
	 * Find the root node of the tree
	 * @return the root node
	 */
	public AVLPlayerNode findRoot() {
		AVLPlayerNode curr = this;
		while (curr.parent != null) { // the parent of the root is null
			curr = curr.parent;
		}
		return curr;
	}


	/**
	 * Get the successor of the given node
	 * @param v the given node
	 * @return the successor node, null if not found
	 */
	public AVLPlayerNode BSTSuccessor() {
		AVLPlayerNode v = this;
		if (v.rightChild != null) {
			return v.rightChild.BSTMinimum(); // the successor is the leftmost child of the right subtree
		} else {
			AVLPlayerNode w = v.parent;
			// move up along the tree to find the successor
			while (w != null && v == w.rightChild) {
				v = w;
				w = w.parent;
			}
			return w; // the successor is an ancestor who has a left child who is also an ancestor
		}
	}


	/**
	 * Get the minimum node in the subtree with the root "this"
	 * @return the minimum node
	 */
	public AVLPlayerNode BSTMinimum() {
		AVLPlayerNode curr = this;
		// move down along the tree to find the leftmost child who is the minimum node
		while (curr.leftChild != null) {
			curr = curr.leftChild;
		}
		return curr;
	}


	/**
	 * This should return the tree of names with parentheses separating subtrees
	 * eg "((bob)alice(bill))"
	 * @return the tree of names with parentheses separating subtrees
	 */
	public String treeString() {
		String s = "";
		if (data != null) {
			s = data.getName(); // get the self name
		}
		if (leftChild != null) {
			s = leftChild.treeString() + s; // add the left subtree
		}
		if (rightChild != null) {
			s = s + rightChild.treeString(); // add the right subtree
		}
		return "(" + s + ")";
	}

	/**
	 * This should return a formatted scoreboard in descending order of value
	 * see example printout in the pdf for the command L
	 * @return a formatted scoreboard
	 */
	public String scoreboard() {
		return "NAME\t\tID\tSCORE\n" + scores();
	}


	/**
	 * Get the EIO score of each player in a format
	 * @return a string of scores
	 */
	public String scores() {
		String s = "";
		if (rightChild != null) {
			s += rightChild.scores(); // get the higher scores
		}
		if (data != null) {
			s += data.getName() + "\t\t" + data.getID() + "\t" + data.getELO() + "\n"; // get the self score
		}
		if (leftChild != null) {
			s += leftChild.scores(); // get the lower scores
		}
		return s;
	}

	/**
	 * Get the balance factor of the node
	 * @return the balance factor
	 */
	public int getBalanceFactor() {
		return balanceFactor;
	}

	/**
	 * Get the right weight of the node
	 * @return the right weight
	 */
	public int getRightWeight() {
		return rightWeight;
	}

	/**
	 * Get the player of the node
	 * @return the player
	 */
	public Player getPlayer() {
		return data;
	}

}
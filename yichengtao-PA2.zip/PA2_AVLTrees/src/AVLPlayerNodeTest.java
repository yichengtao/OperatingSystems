// Yicheng Tao
// yichengtao@brandeis.edu

import static org.junit.Assert.*;
import org.junit.Test;

public class AVLPlayerNodeTest {
	
	public Player p1;
	public Player p2;
	public Player p3;
	public Player p4;
	public Player p5;
	public Player p6;
	public Player p7;
	public Player p8;
	public Player p9;
	public AVLPlayerNode T1;
	public AVLPlayerNode T2;
	public AVLPlayerNode T3;
	public AVLPlayerNode T4;
	public AVLPlayerNode T5;
	public AVLPlayerNode T6;
	
	/**
	 * Constructor
	 */
	public AVLPlayerNodeTest() {
		// 9 players
		p1 = new Player("alice", 1, 1900);
		p2 = new Player("bill", 2, 2000);
		p3 = new Player("dave", 3, 2000);
		p4 = new Player("fred", 4, 2100);
		p5 = new Player("jane", 5, 2200);
		p6 = new Player("joe", 6, 2300);
		p7 = new Player("judy", 7, 2400);
		p8 = new Player("mary", 8, 2500);
		p9 = new Player("tom", 9, 2600);
		// simple ELO tree 1
		T1 = new AVLPlayerNode(p1, p1.getELO());
		// simple ID tree 2
		T2 = new AVLPlayerNode(p3, p3.getID());
		T2 = T2.insert(p2, p2.getID());
		T2 = T2.insert(p4, p4.getID());
		// medium EIO tree 3
		T3 = new AVLPlayerNode(p6, p6.getELO());
		T3 = T3.insert(p9, p9.getELO());
		T3 = T3.insert(p3, p3.getELO());
		T3 = T3.insert(p8, p8.getELO());
		T3 = T3.insert(p4, p4.getELO());
		T3 = T3.insert(p2, p2.getELO());
		T3 = T3.insert(p1, p1.getELO());
		// medium ID tree 4
		T4 = new AVLPlayerNode(p4, p4.getID());
		T4 = T4.insert(p8, p8.getID());
		T4 = T4.insert(p3, p3.getID());
		T4 = T4.insert(p1, p1.getID());
		T4 = T4.insert(p9, p9.getID());
		T4 = T4.insert(p5, p5.getID());
		T4 = T4.insert(p7, p7.getID());
		// complex EIO tree 5
		T5 = new AVLPlayerNode(p7, p7.getELO());
		T5 = T5.insert(p8, p8.getELO());
		T5 = T5.insert(p5, p5.getELO());
		T5 = T5.insert(p6, p6.getELO());
		T5 = T5.insert(p9, p9.getELO());
		T5 = T5.insert(p3, p3.getELO());
		T5 = T5.insert(p4, p4.getELO());
		T5 = T5.insert(p1, p1.getELO());
		// complex ID tree 6
		T6 = new AVLPlayerNode(p5, p5.getID());
		T6 = T6.insert(p8, p8.getID());
		T6 = T6.insert(p3, p3.getID());
		T6 = T6.insert(p2, p2.getID());
		T6 = T6.insert(p9, p9.getID());
		T6 = T6.insert(p6, p6.getID());
		T6 = T6.insert(p7, p7.getID());
		T6 = T6.insert(p4, p4.getID());
		T6 = T6.insert(p1, p1.getID());
	}

	@Test
	public void testInsertAndRotateRight() {
		AVLPlayerNode ELOTree1 = new AVLPlayerNode(p9, p9.getELO());
		ELOTree1 = ELOTree1.insert(p8, p8.getELO());
		ELOTree1 = ELOTree1.insert(p7, p7.getELO());
		// test rotate right
		assertEquals("((judy)mary(tom))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.insert(p6, p6.getELO());
		ELOTree1 = ELOTree1.insert(p5, p5.getELO());
		// test rotate right
		assertEquals("(((jane)joe(judy))mary(tom))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.insert(p4, p4.getELO());
		// test rotate right
		assertEquals("(((fred)jane)joe((judy)mary(tom)))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.insert(p3, p3.getELO());
		// test rotate right
		assertEquals("(((dave)fred(jane))joe((judy)mary(tom)))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.insert(p2, p2.getELO());
		ELOTree1 = ELOTree1.insert(p1, p1.getELO());
		assertEquals("((((alice)bill(dave))fred(jane))joe((judy)mary(tom)))", ELOTree1.treeString());
		// test right weight and balance factor after insertion
		assertEquals(0, ELOTree1.getNode(p1.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p5.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p7.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p9.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p2.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p8.getELO()).getBalanceFactor());
		assertEquals(1, ELOTree1.getNode(p4.getELO()).getBalanceFactor());
		assertEquals(1, ELOTree1.getNode(p6.getELO()).getBalanceFactor());
		assertEquals(0, ELOTree1.getNode(p1.getELO()).getRightWeight());
		assertEquals(0, ELOTree1.getNode(p5.getELO()).getRightWeight());
		assertEquals(0, ELOTree1.getNode(p7.getELO()).getRightWeight());
		assertEquals(0, ELOTree1.getNode(p9.getELO()).getRightWeight());
		assertEquals(1, ELOTree1.getNode(p2.getELO()).getRightWeight());
		assertEquals(1, ELOTree1.getNode(p4.getELO()).getRightWeight());
		assertEquals(1, ELOTree1.getNode(p8.getELO()).getRightWeight());
		assertEquals(3, ELOTree1.getNode(p6.getELO()).getRightWeight());
	}
	
	@Test
	public void testInsertAndRotateLeft() {
		AVLPlayerNode IDTree2 = new AVLPlayerNode(p1, p1.getID());
		IDTree2 = IDTree2.insert(p2, p2.getID());
		IDTree2 = IDTree2.insert(p3, p3.getID());
		// test rotate left
		assertEquals("((alice)bill(dave))", IDTree2.treeString());
		IDTree2 = IDTree2.insert(p4, p4.getID());
		IDTree2 = IDTree2.insert(p5, p5.getID());
		// test rotate left
		assertEquals("((alice)bill((dave)fred(jane)))", IDTree2.treeString());
		IDTree2 = IDTree2.insert(p6, p6.getID());
		// test rotate left
		assertEquals("(((alice)bill(dave))fred(jane(joe)))", IDTree2.treeString());
		IDTree2 = IDTree2.insert(p7, p7.getID());
		// test rotate left
		assertEquals("(((alice)bill(dave))fred((jane)joe(judy)))", IDTree2.treeString());
		IDTree2 = IDTree2.insert(p8, p8.getID());
		IDTree2 = IDTree2.insert(p9, p9.getID());
		assertEquals("(((alice)bill(dave))fred((jane)joe((judy)mary(tom))))", IDTree2.treeString());
		// test right weight and balance factor after insertion
		assertEquals(0, IDTree2.getNode(p1.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p2.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p3.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p5.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p7.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p8.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p9.getID()).getBalanceFactor());
		assertEquals(-1, IDTree2.getNode(p6.getID()).getBalanceFactor());
		assertEquals(-1, IDTree2.getNode(p4.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p1.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p3.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p5.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p7.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p9.getID()).getRightWeight());
		assertEquals(1, IDTree2.getNode(p2.getID()).getRightWeight());
		assertEquals(1, IDTree2.getNode(p8.getID()).getRightWeight());
		assertEquals(3, IDTree2.getNode(p6.getID()).getRightWeight());
		assertEquals(5, IDTree2.getNode(p4.getID()).getRightWeight());
	}
	
	@Test
	public void testDeleteAndRotateAfterDeletion() {
		AVLPlayerNode IDTree2 = new AVLPlayerNode(p1, p1.getID());
		IDTree2 = IDTree2.insert(p2, p2.getID());
		IDTree2 = IDTree2.insert(p3, p3.getID());
		IDTree2 = IDTree2.insert(p4, p4.getID());
		IDTree2 = IDTree2.insert(p5, p5.getID());
		IDTree2 = IDTree2.insert(p6, p6.getID());
		IDTree2 = IDTree2.insert(p7, p7.getID());
		IDTree2 = IDTree2.insert(p8, p8.getID());
		IDTree2 = IDTree2.insert(p9, p9.getID());
		IDTree2 = IDTree2.delete(p4.getID());
		assertEquals("(((alice)bill(dave))jane((joe(judy))mary(tom)))", IDTree2.treeString());
		assertEquals(-1, IDTree2.getNode(p5.getID()).getBalanceFactor());
		assertEquals(1, IDTree2.getNode(p8.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p7.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p2.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p9.getID()).getBalanceFactor());
		assertEquals(-1, IDTree2.getNode(p6.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p3.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p1.getID()).getBalanceFactor());
		assertEquals(4, IDTree2.getNode(p5.getID()).getRightWeight());
		assertEquals(1, IDTree2.getNode(p8.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p9.getID()).getRightWeight());
		assertEquals(1, IDTree2.getNode(p6.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p7.getID()).getRightWeight());
		assertEquals(1, IDTree2.getNode(p2.getID()).getRightWeight());
		assertEquals(0, IDTree2.getNode(p1.getID()).getBalanceFactor());
		assertEquals(0, IDTree2.getNode(p3.getID()).getBalanceFactor());
		IDTree2 = IDTree2.delete(p1.getID());
		assertEquals("((bill(dave))jane((joe(judy))mary(tom)))", IDTree2.treeString());
		IDTree2 = IDTree2.delete(p6.getID());
		assertEquals("((bill(dave))jane((judy)mary(tom)))", IDTree2.treeString());
		IDTree2 = IDTree2.delete(p2.getID());
		assertEquals("((dave)jane((judy)mary(tom)))", IDTree2.treeString());
		IDTree2 = IDTree2.delete(p8.getID());
		assertEquals("((dave)jane((judy)tom))", IDTree2.treeString());
		IDTree2 = IDTree2.delete(p3.getID());
		IDTree2 = IDTree2.delete(p4.getID());
		IDTree2 = IDTree2.delete(p5.getID());
		assertEquals("(judy(tom))", IDTree2.treeString());
		AVLPlayerNode ELOTree1 = new AVLPlayerNode(p9, p9.getELO());
		ELOTree1 = ELOTree1.insert(p8, p8.getELO());
		ELOTree1 = ELOTree1.insert(p7, p7.getELO());
		ELOTree1 = ELOTree1.insert(p6, p6.getELO());
		ELOTree1 = ELOTree1.insert(p5, p5.getELO());
		ELOTree1 = ELOTree1.insert(p4, p4.getELO());
		ELOTree1 = ELOTree1.insert(p3, p3.getELO());
		ELOTree1 = ELOTree1.insert(p2, p2.getELO());
		ELOTree1 = ELOTree1.insert(p1, p1.getELO());
		ELOTree1 = ELOTree1.delete(p6.getELO());
		assertEquals("((((alice)bill(dave))fred(jane))judy(mary(tom)))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p5.getELO());
		assertEquals("(((alice)bill((dave)fred))judy(mary(tom)))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p4.getELO());
		assertEquals("(((alice)bill(dave))judy(mary(tom)))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p7.getELO());
		assertEquals("(((alice)bill(dave))mary(tom))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p8.getELO());
		assertEquals("((alice)bill((dave)tom))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p9.getELO());
		assertEquals("((alice)bill(dave))", ELOTree1.treeString());
		ELOTree1 = ELOTree1.delete(p1.getELO());
		assertEquals("(bill(dave))", ELOTree1.treeString());
	}
	
	@Test
	public void testRotateAfterInsertion() {
		AVLPlayerNode T = new AVLPlayerNode(p1, p1.getID());
		T = T.insert(p5, p5.getID());
		T = T.insert(p2, p2.getID());
		// test RL-rotation
		assertEquals("((alice)bill(jane))", T.treeString());
		T = T.insert(p4, p4.getID());
		T = T.insert(p7, p7.getID());
		T = T.insert(p3, p3.getID());
		// test RL-rotation
		assertEquals("(((alice)bill(dave))fred(jane(judy)))", T.treeString());
		T = T.insert(p6, p6.getID());
		// test RL-rotation
		assertEquals("(((alice)bill(dave))fred((jane)joe(judy)))", T.treeString());
		T = T.insert(p9, p9.getID());
		// test right weight and balance factor
		assertEquals(0, T.getNode(p1.getID()).getRightWeight());
		assertEquals(0, T.getNode(p3.getID()).getRightWeight());
		assertEquals(0, T.getNode(p5.getID()).getRightWeight());
		assertEquals(0, T.getNode(p9.getID()).getRightWeight());
		assertEquals(1, T.getNode(p2.getID()).getRightWeight());
		assertEquals(1, T.getNode(p7.getID()).getRightWeight());
		assertEquals(2, T.getNode(p6.getID()).getRightWeight());
		assertEquals(4, T.getNode(p4.getID()).getRightWeight());
		assertEquals(0, T.getNode(p1.getID()).getBalanceFactor());
		assertEquals(0, T.getNode(p2.getID()).getBalanceFactor());
		assertEquals(0, T.getNode(p3.getID()).getBalanceFactor());
		assertEquals(0, T.getNode(p5.getID()).getBalanceFactor());
		assertEquals(0, T.getNode(p9.getID()).getBalanceFactor());
		assertEquals(-1, T.getNode(p6.getID()).getBalanceFactor());
		assertEquals(-1, T.getNode(p7.getID()).getBalanceFactor());
		assertEquals(-1, T.getNode(p4.getID()).getBalanceFactor());
		
		AVLPlayerNode K = new AVLPlayerNode(p9, p9.getELO());
		K = K.insert(p5, p5.getELO());
		K = K.insert(p8, p8.getELO());
		// test LR-rotation
		assertEquals("((jane)mary(tom))", K.treeString());
		K = K.insert(p6, p6.getELO());
		K = K.insert(p3, p3.getELO());
		K = K.insert(p7, p7.getELO());
		// test LR-rotation
		assertEquals("(((dave)jane)joe((judy)mary(tom)))", K.treeString());
		K = K.insert(p4, p4.getELO());
		// test LR-rotation
		assertEquals("(((dave)fred(jane))joe((judy)mary(tom)))", K.treeString());
		K = K.insert(p1, p1.getELO());
		// test right weight and balance factor
		assertEquals(0, K.getNode(p1.getELO()).getRightWeight());
		assertEquals(0, K.getNode(p3.getELO()).getRightWeight());
		assertEquals(0, K.getNode(p5.getELO()).getRightWeight());
		assertEquals(0, K.getNode(p7.getELO()).getRightWeight());
		assertEquals(0, K.getNode(p9.getELO()).getRightWeight());
		assertEquals(1, K.getNode(p4.getELO()).getRightWeight());
		assertEquals(1, K.getNode(p8.getELO()).getRightWeight());
		assertEquals(3, K.getNode(p6.getELO()).getRightWeight());
		assertEquals(0, K.getNode(p1.getELO()).getBalanceFactor());
		assertEquals(0, K.getNode(p7.getELO()).getBalanceFactor());
		assertEquals(0, K.getNode(p8.getELO()).getBalanceFactor());
		assertEquals(0, K.getNode(p9.getELO()).getBalanceFactor());
		assertEquals(0, K.getNode(p5.getELO()).getBalanceFactor());
		assertEquals(1, K.getNode(p3.getELO()).getBalanceFactor());
		assertEquals(1, K.getNode(p4.getELO()).getBalanceFactor());
		assertEquals(1, K.getNode(p6.getELO()).getBalanceFactor());
	}
	
	@Test
	public void testGetPlayerAndNodeAndRank() {
		// ELOTree 1
		AVLPlayerNode ELOTree1 = new AVLPlayerNode(p9, p9.getELO());
		ELOTree1 = ELOTree1.insert(p8, p8.getELO());
		ELOTree1 = ELOTree1.insert(p7, p7.getELO());
		ELOTree1 = ELOTree1.insert(p6, p6.getELO());
		ELOTree1 = ELOTree1.insert(p5, p5.getELO());
		ELOTree1 = ELOTree1.insert(p4, p4.getELO());
		ELOTree1 = ELOTree1.insert(p3, p3.getELO());
		ELOTree1 = ELOTree1.insert(p2, p2.getELO());
		ELOTree1 = ELOTree1.insert(p1, p1.getELO());
		// make a tree IDTree1 corresponding to ELOTree1
		AVLPlayerNode IDTree1 = new AVLPlayerNode(p9, p9.getID());
		IDTree1 = IDTree1.insert(p8, p8.getID());
		IDTree1 = IDTree1.insert(p7, p7.getID());
		IDTree1 = IDTree1.insert(p6, p6.getID());
		IDTree1 = IDTree1.insert(p5, p5.getID());
		IDTree1 = IDTree1.insert(p4, p4.getID());
		IDTree1 = IDTree1.insert(p3, p3.getID());
		IDTree1 = IDTree1.insert(p2, p2.getID());
		IDTree1 = IDTree1.insert(p1, p1.getID());
		// test getPlayer, getNode, getRank
		assertEquals(1900, ELOTree1.getNode(1900).getPlayer().getELO(), 0.01);
		assertEquals(2000, ELOTree1.getNode(2000).getPlayer().getELO(), 0.01);
		assertEquals(2100, ELOTree1.getNode(2100).getPlayer().getELO(), 0.01);
		assertEquals(2200, ELOTree1.getNode(2200).getPlayer().getELO(), 0.01);
		assertEquals(2300, ELOTree1.getNode(2300).getPlayer().getELO(), 0.01);
		assertEquals(2400, ELOTree1.getNode(2400).getPlayer().getELO(), 0.01);
		assertEquals(2500, ELOTree1.getNode(2500).getPlayer().getELO(), 0.01);
		assertEquals(2600, ELOTree1.getNode(2600).getPlayer().getELO(), 0.01);
		assertEquals(9, ELOTree1.getRank(IDTree1.getPlayer(1).getELO()));
		assertEquals(7, ELOTree1.getRank(IDTree1.getPlayer(2).getELO()));
		assertEquals(7, ELOTree1.getRank(IDTree1.getPlayer(3).getELO()));
		assertEquals(6, ELOTree1.getRank(IDTree1.getPlayer(4).getELO()));
		assertEquals(5, ELOTree1.getRank(IDTree1.getPlayer(5).getELO()));
		assertEquals(4, ELOTree1.getRank(IDTree1.getPlayer(6).getELO()));
		assertEquals(3, ELOTree1.getRank(IDTree1.getPlayer(7).getELO()));
		assertEquals(2, ELOTree1.getRank(IDTree1.getPlayer(8).getELO()));
		assertEquals(1, ELOTree1.getRank(IDTree1.getPlayer(9).getELO()));
		// make a tree ELOTree2 corresponding to IDTree2 
		AVLPlayerNode ELOTree2 = new AVLPlayerNode(p1, p1.getELO());
		ELOTree2 = ELOTree2.insert(p2, p2.getELO());
		ELOTree2 = ELOTree2.insert(p3, p3.getELO());
		ELOTree2 = ELOTree2.insert(p4, p4.getELO());
		ELOTree2 = ELOTree2.insert(p5, p5.getELO());
		ELOTree2 = ELOTree2.insert(p6, p6.getELO());
		ELOTree2 = ELOTree2.insert(p7, p7.getELO());
		ELOTree2 = ELOTree2.insert(p8, p8.getELO());
		ELOTree2 = ELOTree2.insert(p9, p9.getELO());
		// IDTree2
		AVLPlayerNode IDTree2 = new AVLPlayerNode(p1, p1.getID());
		IDTree2 = IDTree2.insert(p2, p2.getID());
		IDTree2 = IDTree2.insert(p3, p3.getID());
		IDTree2 = IDTree2.insert(p4, p4.getID());
		IDTree2 = IDTree2.insert(p5, p5.getID());
		IDTree2 = IDTree2.insert(p6, p6.getID());
		IDTree2 = IDTree2.insert(p7, p7.getID());
		IDTree2 = IDTree2.insert(p8, p8.getID());
		IDTree2 = IDTree2.insert(p9, p9.getID());
		// test getPlayer, getNode, getRank
		assertEquals(1, IDTree2.getNode(1).getPlayer().getID());
		assertEquals(2, IDTree2.getNode(2).getPlayer().getID());
		assertEquals(3, IDTree2.getNode(3).getPlayer().getID());
		assertEquals(4, IDTree2.getNode(4).getPlayer().getID());
		assertEquals(5, IDTree2.getNode(5).getPlayer().getID());
		assertEquals(6, IDTree2.getNode(6).getPlayer().getID());
		assertEquals(7, IDTree2.getNode(7).getPlayer().getID());
		assertEquals(8, IDTree2.getNode(8).getPlayer().getID());
		assertEquals(9, IDTree2.getNode(9).getPlayer().getID());
		assertEquals(9, ELOTree2.getRank(IDTree2.getPlayer(1).getELO()));
		assertEquals(7, ELOTree2.getRank(IDTree2.getPlayer(2).getELO()));
		assertEquals(7, ELOTree2.getRank(IDTree2.getPlayer(3).getELO()));
		assertEquals(6, ELOTree2.getRank(IDTree2.getPlayer(4).getELO()));
		assertEquals(5, ELOTree2.getRank(IDTree2.getPlayer(5).getELO()));
		assertEquals(4, ELOTree2.getRank(IDTree2.getPlayer(6).getELO()));
		assertEquals(3, ELOTree2.getRank(IDTree2.getPlayer(7).getELO()));
		assertEquals(2, ELOTree2.getRank(IDTree2.getPlayer(8).getELO()));
		assertEquals(1, ELOTree2.getRank(IDTree2.getPlayer(9).getELO()));
	}
	
	@Test
	public void testSetRightWeightForAncestors() {
		// Test setRightWeightForAncestors(1)
		assertEquals(0, T1.getNode(p1.getELO()).getRightWeight());
		assertEquals(0, T5.getNode(p1.getELO()).getRightWeight());
		assertEquals(1, T5.getNode(p3.getELO()).getRightWeight());
		assertEquals(0, T5.getNode(p4.getELO()).getRightWeight());
		assertEquals(1, T5.getNode(p5.getELO()).getRightWeight());
		assertEquals(0, T5.getNode(p6.getELO()).getRightWeight());
		assertEquals(2, T5.getNode(p7.getELO()).getRightWeight());
		assertEquals(1, T5.getNode(p8.getELO()).getRightWeight());
		assertEquals(0, T5.getNode(p9.getELO()).getRightWeight());
		assertEquals(0, T6.getNode(p1.getID()).getRightWeight());
		assertEquals(0, T6.getNode(p2.getID()).getRightWeight());
		assertEquals(1, T6.getNode(p3.getID()).getRightWeight());
		assertEquals(0, T6.getNode(p4.getID()).getRightWeight());
		assertEquals(4, T6.getNode(p5.getID()).getRightWeight());
		assertEquals(1, T6.getNode(p8.getID()).getRightWeight());
		assertEquals(1, T6.getNode(p6.getID()).getRightWeight());
		assertEquals(0, T6.getNode(p9.getID()).getRightWeight());
		assertEquals(0, T6.getNode(p7.getID()).getRightWeight());
		// Test setRightWeightForAncestors(-1)
		AVLPlayerNode T7 = new AVLPlayerNode(p5, p5.getID());
		T7 = T7.insert(p8, p8.getID());
		T7 = T7.insert(p3, p3.getID());
		T7 = T7.insert(p2, p2.getID());
		T7 = T7.insert(p9, p9.getID());
		T7 = T7.insert(p6, p6.getID());
		T7 = T7.insert(p7, p7.getID());
		T7 = T7.insert(p4, p4.getID());
		T7 = T7.insert(p1, p1.getID());
		T7 = T7.delete(p8.getID());
		T7 = T7.delete(p3.getID());
		assertEquals(0, T7.getNode(p1.getID()).getRightWeight());
		assertEquals(1, T7.getNode(p2.getID()).getRightWeight());
		assertEquals(0, T7.getNode(p4.getID()).getRightWeight());
		assertEquals(3, T7.getNode(p5.getID()).getRightWeight());
		assertEquals(0, T7.getNode(p6.getID()).getRightWeight());
		assertEquals(0, T7.getNode(p9.getID()).getRightWeight());
		assertEquals(1, T7.getNode(p7.getID()).getRightWeight());
		AVLPlayerNode T8 = new AVLPlayerNode(p7, p7.getELO());
		T8 = T8.insert(p8, p8.getELO());
		T8 = T8.insert(p5, p5.getELO());
		T8 = T8.insert(p6, p6.getELO());
		T8 = T8.insert(p9, p9.getELO());
		T8 = T8.insert(p3, p3.getELO());
		T8 = T8.insert(p4, p4.getELO());
		T8 = T8.insert(p1, p1.getELO());
		T8 = T8.delete(p7.getELO());
		assertEquals(0, T8.getNode(p1.getELO()).getRightWeight());
		assertEquals(1, T8.getNode(p3.getELO()).getRightWeight());
		assertEquals(0, T8.getNode(p4.getELO()).getRightWeight());
		assertEquals(3, T8.getNode(p5.getELO()).getRightWeight());
		assertEquals(0, T8.getNode(p6.getELO()).getRightWeight());
		assertEquals(1, T8.getNode(p8.getELO()).getRightWeight());
		assertEquals(0, T8.getNode(p9.getELO()).getRightWeight());
	}
	
	@Test
	public void testGetHeight() {
		assertEquals(0, T1.getHeight(T1.getNode(p1.getELO())));
		assertEquals(0, T2.getHeight(T2.getNode(p2.getID())));
		assertEquals(1, T2.getHeight(T2.getNode(p3.getID())));
		assertEquals(2, T3.getHeight(T3.getNode(p3.getELO())));
		assertEquals(3, T3.getHeight(T3.getNode(p6.getELO())));
		assertEquals(3, T4.getHeight(T4.getNode(p4.getID())));
		assertEquals(2, T4.getHeight(T4.getNode(p8.getID())));
		assertEquals(2, T5.getHeight(T5.getNode(p5.getELO())));
		assertEquals(0, T5.getHeight(T5.getNode(p4.getELO())));
		assertEquals(3, T6.getHeight(T6.getNode(p5.getID())));
		assertEquals(2, T6.getHeight(T6.getNode(p8.getID())));
		assertEquals(-1, T4.getHeight(T4.getNode(p2.getID())));
		assertEquals(-1, T3.getHeight(T3.getNode(p7.getELO())));
	}
	
	@Test
	public void testSetBFAndHeightForSelfAndAnc() {
		assertEquals(0, T1.getHeight(T1.getNode(p1.getELO())));
		assertEquals(0, T1.getHeight(T1.getNode(p1.getELO())));
		assertEquals(0, T5.getNode(p1.getELO()).getBalanceFactor());
		assertEquals(0, T5.getNode(p4.getELO()).getBalanceFactor());
		assertEquals(0, T5.getNode(p3.getELO()).getBalanceFactor());
		assertEquals(1, T5.getNode(p5.getELO()).getBalanceFactor());
		assertEquals(0, T5.getNode(p6.getELO()).getBalanceFactor());
		assertEquals(1, T5.getNode(p7.getELO()).getBalanceFactor());
		assertEquals(-1, T5.getNode(p8.getELO()).getBalanceFactor());
		assertEquals(0, T5.getNode(p9.getELO()).getBalanceFactor());
		assertEquals(0, T6.getNode(p1.getID()).getBalanceFactor());
		assertEquals(1, T6.getNode(p2.getID()).getBalanceFactor());
		assertEquals(0, T6.getNode(p4.getID()).getBalanceFactor());
		assertEquals(1, T6.getNode(p3.getID()).getBalanceFactor());
		assertEquals(0, T6.getNode(p5.getID()).getBalanceFactor());
		assertEquals(1, T6.getNode(p8.getID()).getBalanceFactor());
		assertEquals(0, T6.getNode(p9.getID()).getBalanceFactor());
		assertEquals(-1, T6.getNode(p6.getID()).getBalanceFactor());
		assertEquals(0, T6.getNode(p7.getID()).getBalanceFactor());
		assertEquals(0, T5.getHeight(T5.getNode(p1.getELO())));
		assertEquals(0, T5.getHeight(T5.getNode(p4.getELO())));
		assertEquals(1, T5.getHeight(T5.getNode(p3.getELO())));
		assertEquals(0, T5.getHeight(T5.getNode(p6.getELO())));
		assertEquals(2, T5.getHeight(T5.getNode(p5.getELO())));
		assertEquals(3, T5.getHeight(T5.getNode(p7.getELO())));
		assertEquals(1, T5.getHeight(T5.getNode(p8.getELO())));
		assertEquals(0, T5.getHeight(T5.getNode(p9.getELO())));
		assertEquals(0, T5.getHeight(T5.getNode(p1.getELO())));
		assertEquals(0, T6.getHeight(T6.getNode(p1.getID())));
		assertEquals(1, T6.getHeight(T6.getNode(p2.getID())));
		assertEquals(0, T6.getHeight(T6.getNode(p4.getID())));
		assertEquals(2, T6.getHeight(T6.getNode(p3.getID())));
		assertEquals(3, T6.getHeight(T6.getNode(p5.getID())));
		assertEquals(2, T6.getHeight(T6.getNode(p8.getID())));
		assertEquals(0, T6.getHeight(T6.getNode(p9.getID())));
		assertEquals(1, T6.getHeight(T6.getNode(p6.getID())));
		assertEquals(0, T6.getHeight(T6.getNode(p7.getID())));
	}
	
	@Test
	public void testFindRoot() {
		assertEquals(T1.getNode(p1.getELO()), T1.findRoot());
		assertEquals(T2.getNode(p3.getID()), T2.getNode(p2.getID()).findRoot());
		assertEquals(T3.getNode(p6.getELO()), T3.getNode(p1.getELO()).findRoot());
		assertEquals(T3.getNode(p6.getELO()), T3.getNode(p8.getELO()).findRoot());
		assertEquals(T4.getNode(p4.getID()), T4.getNode(p1.getID()).findRoot());
		assertEquals(T4.getNode(p4.getID()), T4.getNode(p7.getID()).findRoot());
		assertEquals(T5.getNode(p7.getELO()), T5.getNode(p4.getELO()).findRoot());
		assertEquals(T5.getNode(p7.getELO()), T5.getNode(p6.getELO()).findRoot());
		assertEquals(T6.getNode(p5.getID()), T6.getNode(p1.getID()).findRoot());
		assertEquals(T6.getNode(p5.getID()), T6.getNode(p1.getID()).findRoot());
	}
	
	@Test
	public void testBSTSuccessor() {
		assertEquals(null, T1.getNode(p1.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p3.getELO()), T5.getNode(p1.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p4.getELO()), T5.getNode(p3.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p5.getELO()), T5.getNode(p4.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p6.getELO()), T5.getNode(p5.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p7.getELO()), T5.getNode(p6.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p8.getELO()), T5.getNode(p7.getELO()).BSTSuccessor());
		assertEquals(T5.getNode(p9.getELO()), T5.getNode(p8.getELO()).BSTSuccessor());
		assertEquals(null, T5.getNode(p9.getELO()).BSTSuccessor());
		assertEquals(T6.getNode(p2.getID()), T6.getNode(p1.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p3.getID()), T6.getNode(p2.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p4.getID()), T6.getNode(p3.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p5.getID()), T6.getNode(p4.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p6.getID()), T6.getNode(p5.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p7.getID()), T6.getNode(p6.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p8.getID()), T6.getNode(p7.getID()).BSTSuccessor());
		assertEquals(T6.getNode(p9.getID()), T6.getNode(p8.getID()).BSTSuccessor());
		assertEquals(null, T6.getNode(p9.getID()).BSTSuccessor());
	}
	
	@Test
	public void testBSTMinimum() {
		assertEquals(T1.getNode(p1.getELO()), T1.BSTMinimum());
		assertEquals(T2.getNode(p2.getID()), T2.BSTMinimum());
		assertEquals(T3.getNode(p1.getELO()), T3.BSTMinimum());
		assertEquals(T4.getNode(p1.getID()), T4.BSTMinimum());
		assertEquals(T5.getNode(p1.getELO()), T5.BSTMinimum());
		assertEquals(T6.getNode(p1.getID()), T6.BSTMinimum());
		assertEquals(T3.getNode(p8.getELO()), T3.getNode(p9.getELO()).BSTMinimum());
		assertEquals(T4.getNode(p5.getID()), T4.getNode(p8.getID()).BSTMinimum());
		assertEquals(T6.getNode(p6.getID()), T6.getNode(p8.getID()).BSTMinimum());
	}
	
	@Test
	public void testTreeString() {
		assertEquals("(alice)", T1.treeString());
		assertEquals("((bill)dave(fred))", T2.treeString());
		assertEquals("((((alice)bill)dave(fred))joe((mary)tom))", T3.treeString());
		assertEquals("(((alice)dave)fred((jane(judy))mary(tom)))", T4.treeString());
		assertEquals("((((alice)dave(fred))jane(joe))judy(mary(tom)))", T5.treeString());
		assertEquals("((((alice)bill)dave(fred))jane((joe(judy))mary(tom)))", T6.treeString());
	}
	
	@Test 
	public void testScoreboardAndScores() {
		assertEquals("NAME\t\tID\tSCORE\nalice\t\t1\t1900.0\n", T1.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nbill\t\t2\t2000.0\n", T2.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njoe\t\t6\t2300.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nbill\t\t2\t2000.0\nalice\t\t1\t1900.0\n", T3.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njudy\t\t7\t2400.0\njane\t\t5\t2200.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nalice\t\t1\t1900.0\n", T4.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njudy\t\t7\t2400.0\njoe\t\t6\t2300.0\njane\t\t5\t2200.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nalice\t\t1\t1900.0\n", T5.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njudy\t\t7\t2400.0\njoe\t\t6\t2300.0\njane\t\t5\t2200.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nbill\t\t2\t2000.0\nalice\t\t1\t1900.0\n", T6.scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ndave\t\t3\t2000.0\nalice\t\t1\t1900.0\n", T4.getNode(p3.getID()).scoreboard());
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njudy\t\t7\t2400.0\njoe\t\t6\t2300.0\n", T6.getNode(p8.getID()).scoreboard());
		assertEquals("NAME\t\tID\tSCORE\njoe\t\t6\t2300.0\njane\t\t5\t2200.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nalice\t\t1\t1900.0\n", T5.getNode(p5.getELO()).scoreboard());
	}
	
	@Test
	public void TestAll() {
		AVLPlayerNode T = new AVLPlayerNode(p3, p3.getELO());
		// Test treeString()
		assertEquals("(dave)", T.treeString());
		// Test scoreboard()
		assertEquals("NAME\t\tID\tSCORE\ndave\t\t3\t2000.0\n", T.scoreboard());
		T = T.insert(p6, p6.getELO());
		// Test treeString()
		assertEquals("(dave(joe))", T.treeString());
		// Test scoreboard()
		assertEquals("NAME\t\tID\tSCORE\njoe\t\t6\t2300.0\ndave\t\t3\t2000.0\n", T.scoreboard());
		T = T.insert(p9, p9.getELO());
		// Test rotateLeft()
		assertEquals("((dave)joe(tom))", T.treeString());
		// Test scoreboard()
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\njoe\t\t6\t2300.0\ndave\t\t3\t2000.0\n", T.scoreboard());
		T = T.insert(p8, p8.getELO());
		T = T.insert(p7, p7.getELO());
		// Test rotateRight()
		assertEquals("((dave)joe((judy)mary(tom)))", T.treeString());
		T = T.insert(p1, p1.getELO());
		T = T.insert(p2, p2.getELO());
		// Test left-then-right rotate()
		assertEquals("(((alice)bill(dave))joe((judy)mary(tom)))", T.treeString());
		T = T.insert(p5, p5.getELO());
		T = T.insert(p4, p4.getELO());
		// Test right-then-left rotate()
		assertEquals("(((alice)bill((dave)fred(jane)))joe((judy)mary(tom)))", T.treeString());
		// Test scoreboard()
		assertEquals("NAME\t\tID\tSCORE\ntom\t\t9\t2600.0\nmary\t\t8\t2500.0\njudy\t\t7\t2400.0\njoe\t\t6\t2300.0\njane\t\t5\t2200.0\nfred\t\t4\t2100.0\ndave\t\t3\t2000.0\nbill\t\t2\t2000.0\nalice\t\t1\t1900.0\n", T.scoreboard());
	}
}
